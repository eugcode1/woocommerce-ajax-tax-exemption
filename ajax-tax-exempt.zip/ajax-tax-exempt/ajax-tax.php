<?php
/**
 * Plugin Name: Ajax Tax Exempt
 * Plugin URI: https://github.com/euglin1130/woocommerce-ajax-tax-exemption
 * Description: This is a plugin that allows customer to choose exempt for tax in Woocommerce billing form
 * Version: 1.0.0
 * Author: raneplus
 * Author URI: http://euglin1130.github.io
 * License: GPL2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	add_action('wp_enqueue_scripts', 'ajax_test_enqueue_scripts2');
	function ajax_test_enqueue_scripts2()
	{

		wp_enqueue_script('exempttax', plugins_url('/exempttax.js', __FILE__), array('jquery'), '1.0', true);

		//get unified ajax from core 'wp-admin/admin-ajax.php'
		wp_localize_script('exempttax', 'ajaxtest', array(
			'ajax_url' => admin_url('admin-ajax.php')
		));
	}


//add contents in woocommerce billing form
	add_action('woocommerce_after_checkout_billing_form', 'ajax_text_display', 10);
	function ajax_text_display()
	{
		$user_id = get_current_user_id();
		$key = 'ft_tax_status';
		$single = 'true';
		$tax_status = get_user_meta($user_id, $key, $single);
		$tax_status = (empty($tax_status)) ? 0 : $tax_status;

		if ($tax_status == 0) {
			$tax_check_text = '<p>Tax Exemption? Check only if your purchase is qualified <input id="tax-checkbox" class="input-checkbox" type="checkbox" value="' . $user_id . '"  ><span id="tax-check-status"></span></p>';
		} else {
			$tax_check_text = '<p>Tax Exemption? Check only if your purchase is qualified <input id="tax-checkbox" class="input-checkbox" type="checkbox" value="' . $user_id . '"  checked = "checked"><span id="tax-check-status"></span></p>';
		}
		echo $tax_check_text;


	}

//function to process data send through ajax
	add_action('wp_ajax_nopriv_test_ajax_tax_checkbox', 'test_ajax_tax_checkbox');
	add_action('wp_ajax_test_ajax_tax_checkbox', 'test_ajax_tax_checkbox');
	function test_ajax_tax_checkbox()
	{
		$user_id = $_REQUEST['user_id'];
		//if user is not logged in
		if ($user_id == 0) {
			echo "<span style='color:red;'> you need to login first </span>";
			die();
		} else {
			$tax_status = get_user_meta($user_id, 'ft_tax_status', true);
			$tax_status = ($tax_status == 1) ? 0 : 1;
			update_user_meta($user_id, 'ft_tax_status', $tax_status);
			if (defined('DOING_AJAX') && DOING_AJAX) {
				echo "<span style='color:red;'> Wait. Recalculate your order total now...</span>";
				die();// Always die in functions echoing ajax content
			} else {
				global $woocommerce;
				$checkout_url = $woocommerce->cart->get_checkout_url();
				wp_redirect($checkout_url);
				exit();
			}
		}


	}


	/**tax emption for woocommerce***/
	add_filter('woocommerce_before_checkout_billing_form', 'prevent_wholesaler_taxes');
	function prevent_wholesaler_taxes()
	{
		global $woocommerce;
		$key = 'ft_tax_status';
		$single = 'true';
		$user_id = get_current_user_id();
		$tax_status = get_user_meta($user_id, $key, $single);
		//if the user has capability of taxfree
		//0 need tax(default) 1 does not need tax
		if ($tax_status == 0) {
			$woocommerce->customer->set_is_vat_exempt(false);

		} else {

			$woocommerce->customer->set_is_vat_exempt(true);
			//show tax free warning only if tax is exempt
			add_action('woocommerce_review_order_before_payment', 'tax_status_warning', 10);

		}
	}


	function tax_status_warning()
	{

		echo '<p style="padding-left: 1.387em;color:red;">Notice: your tax is exempted because you claim yourself to be qualified. </p>';
	}

}