
jQuery(document).ready(function($){

	$('#tax-checkbox').live('change', function(){
		var user_id = $(this).val();

			jQuery.ajax({
				url: ajaxtest.ajax_url,
				type: 'post',
				data: {
					action: 'test_ajax_tax_checkbox',
					user_id: user_id
				},
				success: function (response) {
					location.reload(true);
					jQuery('#tax-check-status').html( response );
				}
			});
		return false;
	});
});


